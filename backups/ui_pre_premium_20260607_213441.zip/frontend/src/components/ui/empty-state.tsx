import * as React from 'react'
import { AlertCircle, SearchX, FolderOpen } from 'lucide-react'
import { cn } from '@/lib/utils'

export interface EmptyStateProps {
  /** Variant changes the icon container color */
  variant?: 'default' | 'error' | 'search'
  /** Override the icon entirely */
  icon?: React.ReactNode
  title: string
  description?: string
  /** Buttons or links rendered below the description */
  action?: React.ReactNode
  className?: string
}

const DEFAULT_ICONS: Record<string, React.ReactNode> = {
  default: <FolderOpen className="h-5 w-5" />,
  error:   <AlertCircle className="h-5 w-5" />,
  search:  <SearchX className="h-5 w-5" />,
}

export function EmptyState({
  variant = 'default',
  icon,
  title,
  description,
  action,
  className,
}: EmptyStateProps) {
  return (
    <div className={cn('empty-state', className)}>
      <div className={cn('empty-state-icon', variant === 'error' && 'error')}>
        {icon ?? DEFAULT_ICONS[variant]}
      </div>

      <p className="empty-state-title">{title}</p>

      {description && (
        <p className="empty-state-desc mt-1">{description}</p>
      )}

      {action && (
        <div className="mt-4 flex flex-wrap items-center justify-center gap-2">
          {action}
        </div>
      )}
    </div>
  )
}
