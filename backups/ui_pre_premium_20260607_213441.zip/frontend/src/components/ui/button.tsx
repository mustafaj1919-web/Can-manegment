import * as React from 'react'
import { Slot } from '@radix-ui/react-slot'
import { cva, type VariantProps } from 'class-variance-authority'
import { cn } from '@/lib/utils'

const buttonVariants = cva(
  'inline-flex items-center justify-center gap-2 whitespace-nowrap font-medium ring-offset-background transition-all duration-150 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-1 disabled:pointer-events-none disabled:opacity-45 [&_svg]:pointer-events-none [&_svg]:shrink-0 select-none',
  {
    variants: {
      variant: {
        /* Solid primary — blue */
        default:
          'rounded-lg bg-primary font-semibold text-primary-foreground shadow-sm shadow-primary/25 hover:bg-primary/90 active:scale-[0.98] active:shadow-none',

        /* Destructive — red */
        destructive:
          'rounded-lg bg-destructive font-semibold text-destructive-foreground shadow-sm shadow-destructive/25 hover:bg-destructive/90 active:scale-[0.98]',

        /* Outline — bordered transparent */
        outline:
          'rounded-lg border border-input bg-transparent text-foreground hover:bg-secondary hover:border-border active:scale-[0.98]',

        /* Secondary — muted surface */
        secondary:
          'rounded-lg bg-secondary text-secondary-foreground hover:bg-secondary/70 active:scale-[0.98]',

        /* Ghost — minimal */
        ghost:
          'rounded-lg text-muted-foreground hover:bg-secondary hover:text-foreground active:scale-[0.98]',

        /* Link */
        link:
          'rounded text-primary underline-offset-4 hover:underline p-0 h-auto',

        /* Glass — for elevated surfaces */
        glass:
          'rounded-lg glass-interactive text-foreground',

        /* Accent — emerald */
        accent:
          'rounded-lg bg-accent font-semibold text-accent-foreground shadow-sm shadow-accent/20 hover:bg-accent/90 active:scale-[0.98]',
      },
      size: {
        default: 'h-9 px-4 py-2 text-sm [&_svg]:size-4',
        sm:      'h-7 rounded-md px-3 text-xs [&_svg]:size-3.5',
        lg:      'h-10 rounded-lg px-5 text-sm [&_svg]:size-4',
        xl:      'h-11 rounded-lg px-7 text-base [&_svg]:size-5',
        icon:    'h-9 w-9 rounded-lg [&_svg]:size-4',
        'icon-sm':'h-7 w-7 rounded-md [&_svg]:size-3.5',
        'icon-lg':'h-10 w-10 rounded-lg [&_svg]:size-5',
      },
    },
    defaultVariants: {
      variant: 'default',
      size: 'default',
    },
  }
)

export interface ButtonProps
  extends React.ButtonHTMLAttributes<HTMLButtonElement>,
    VariantProps<typeof buttonVariants> {
  asChild?: boolean
}

const Button = React.forwardRef<HTMLButtonElement, ButtonProps>(
  ({ className, variant, size, asChild = false, ...props }, ref) => {
    const Comp = asChild ? Slot : 'button'
    return (
      <Comp className={cn(buttonVariants({ variant, size, className }))} ref={ref} {...props} />
    )
  }
)
Button.displayName = 'Button'

export { Button, buttonVariants }
